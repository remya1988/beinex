values_dict={
    "num1":10,
    "num2" : 11,
    "num3" : 2,
    "num4" : 14,
    "num5" : 12
}
sorted_list=sorted(values_dict.values())
print(sorted_list)