list = [7,8, 120, 25, 44, 20, 27]
removed_list=[x for x in list if x%2!=0]
print(removed_list)