tuple1 = (11, 22)  
tuple2 = (99, 88)
tuple3=()
print("Before swaping.... ","\n","tuple1 = ",tuple1,"tuple2 = ",tuple2)
tuple3=tuple1
tuple1=tuple2
tuple2=tuple3
print("After swaping.... ","\n","tuple1 = ",tuple1,"tuple2 = ",tuple2)